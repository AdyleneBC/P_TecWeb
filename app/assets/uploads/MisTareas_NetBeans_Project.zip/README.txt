MisTareas - NetBeans-style Java Web project (JSP + Servlets)
-----------------------------------------------------------
Contenido del ZIP:
- src/java/com/mistareas/model/Tarea.java
- src/java/com/mistareas/util/DBUtil.java
- src/java/com/mistareas/servlets/AgregarTareaServlet.java
- src/java/com/mistareas/servlets/EliminarTareaServlet.java
- src/java/com/mistareas/servlets/CambiarStatusServlet.java
- web/index.jsp
- web/lista.jsp
- web/confirmar.jsp
- web/estilos.css
- web/validaciones.js
- web/WEB-INF/web.xml
- sql/create_db.sql

INSTRUCCIONES RÁPIDAS:
1) Crear la base de datos MySQL/MariaDB usando el script sql/create_db.sql
2) Ajustar las credenciales en src/java/com/mistareas/util/DBUtil.java (URL, user, pass).
3) Importar el proyecto en NetBeans como "Existing Project" o crear un nuevo "Web Application"
   y copiar las carpetas: src -> Source Packages, web -> Web Pages.
4) Agregar el driver JDBC (MySQL Connector/J) al classpath / libraries del proyecto.
5) Ejecutar en un servidor compatible (Tomcat, GlassFish) desde NetBeans.
