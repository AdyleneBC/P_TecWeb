function validarForm(){
  var desc = document.getElementById('descripcion').value.trim();
  if(desc.length === 0){
    alert('La descripción no puede quedar vacía.');
    document.getElementById('descripcion').focus();
    return false;
  }
  if(desc.length > 255){
    alert('La descripción es muy larga.');
    return false;
  }
  return true;
}
