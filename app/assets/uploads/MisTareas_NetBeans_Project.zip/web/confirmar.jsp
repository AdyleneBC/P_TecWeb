<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!doctype html>
<html>
<head><meta charset="utf-8"/><title>Confirmación</title><link rel="stylesheet" href="estilos.css"/></head>
<body>
<div class="container">
  <h2>Confirmación</h2>
  <p><%= request.getAttribute("mensaje") %></p>
  <form method="post" action="<%= request.getAttribute('accion') %>">
    <%-- reproducir todos los parámetros para POST si existen --%>
    <input type="hidden" name="id" value="<%= request.getAttribute('id') != null ? request.getAttribute('id') : '' %>"/>
    <input type="hidden" name="descripcion" value="<%= request.getAttribute('descripcion') != null ? request.getAttribute('descripcion') : '' %>"/>
    <div class="actions">
      <button type="submit">Confirmar</button>
      <a class="button" href="index.jsp">Cancelar</a>
    </div>
  </form>
</div>
</body>
</html>
