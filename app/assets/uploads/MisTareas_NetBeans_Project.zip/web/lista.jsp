<%@ page import="java.util.*, com.mistareas.model.Tarea, com.mistareas.util.DBUtil, java.sql.*" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Listado de Tareas</title>
  <link rel="stylesheet" href="estilos.css"/>
  <script>
    function confirmarCambio(id){ if(confirm('¿Cambiar estatus a realizada?')){ window.location='CambiarStatusServlet?id='+id; } }
    function confirmarEliminar(id){ if(confirm('¿Eliminar esta tarea?')){ window.location='EliminarTareaServlet?id='+id; } }
  </script>
</head>
<body>
<div class="container">
  <h1>Lista de Tareas</h1>
  <a class="button" href="index.jsp">Agregar nueva tarea</a>
  <table class="tareas">
    <thead><tr><th>ID</th><th>Descripción</th><th>Fecha</th><th>Estatus</th><th>Acciones</th></tr></thead>
    <tbody>
    <%
      Connection conn = null;
      PreparedStatement ps = null;
      ResultSet rs = null;
      try {
        conn = DBUtil.getConnection();
        ps = conn.prepareStatement("SELECT id, descripcion, fecha_creacion, estatus FROM tareas ORDER BY id DESC");
        rs = ps.executeQuery();
        while(rs.next()){
          int id = rs.getInt("id");
          String descripcion = rs.getString("descripcion");
          Timestamp fecha = rs.getTimestamp("fecha_creacion");
          String estatus = rs.getString("estatus");
    %>
      <tr>
        <td><%= id %></td>
        <td><%= descripcion %></td>
        <td><%= fecha %></td>
        <td><%= estatus %></td>
        <td>
          <% if("pendiente".equalsIgnoreCase(estatus)) { %>
            <button onclick="confirmarCambio(<%= id %>)">Marcar realizada</button>
          <% } else { %>
            <button onclick="confirm('¿Estas seguro?') && (window.location='EliminarTareaServlet?id=<%= id %>')">Eliminar</button>
          <% } %>
        </td>
      </tr>
    <%
        }
      } catch(Exception e){ out.println("<tr><td colspan='5'>Error: "+e.getMessage()+"</td></tr>"); }
      finally{ try{ if(rs!=null) rs.close(); if(ps!=null) ps.close(); if(conn!=null) conn.close(); }catch(Exception e){} }
    %>
    </tbody>
  </table>
</div>
</body>
</html>
