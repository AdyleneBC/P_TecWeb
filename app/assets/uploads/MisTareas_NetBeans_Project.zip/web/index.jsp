<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>MisTareas - Agregar tarea</title>
  <link rel="stylesheet" href="estilos.css"/>
  <script src="validaciones.js"></script>
</head>
<body>
<div class="container">
  <h1>MisTareas</h1>
  <form id="formTarea" action="AgregarTareaServlet" method="post" onsubmit="return validarForm();">
    <label for="descripcion">Descripción:</label>
    <input type="text" id="descripcion" name="descripcion" maxlength="255" required/>
    <div class="actions">
      <button type="submit">Agregar tarea</button>
      <a class="button" href="lista.jsp">Ver lista de tareas</a>
    </div>
  </form>
</div>
</body>
</html>
