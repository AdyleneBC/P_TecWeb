-- Script SQL para crear la base de datos y la tabla 'tareas'
CREATE DATABASE IF NOT EXISTS MisTareasBD CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE MisTareasBD;
CREATE TABLE IF NOT EXISTS tareas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descripcion VARCHAR(255) NOT NULL,
  fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  estatus VARCHAR(20) NOT NULL
);
