package com.mistareas.servlets;

import com.mistareas.util.DBUtil;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet(name = "AgregarTareaServlet", urlPatterns = {"/AgregarTareaServlet"})
public class AgregarTareaServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String descripcion = request.getParameter("descripcion");
        if(descripcion == null || descripcion.trim().isEmpty()){
            response.sendRedirect("index.jsp");
            return;
        }
        // En este diseño simple pedimos confirmación vía JSP (confirmar.jsp)
        request.setAttribute("mensaje", "¿Desea agregar la tarea: " + descripcion + " ?");
        request.setAttribute("descripcion", descripcion);
        request.setAttribute("accion", "AgregarTareaServlet?action=confirm");
        request.getRequestDispatcher("confirmar.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if("confirm".equals(action)){
            String descripcion = request.getParameter("descripcion");
            if(descripcion == null) descripcion = request.getParameter("descripcion");
            // insertar en BD con estatus 'pendiente'
            try(Connection conn = DBUtil.getConnection();
                PreparedStatement ps = conn.prepareStatement("INSERT INTO tareas(descripcion, estatus) VALUES(?, 'pendiente')")){
                ps.setString(1, descripcion);
                ps.executeUpdate();
                response.sendRedirect("lista.jsp");
            } catch(Exception e){
                throw new ServletException(e);
            }
        } else {
            response.sendRedirect("index.jsp");
        }
    }
}
