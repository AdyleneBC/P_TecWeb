package com.mistareas.servlets;

import com.mistareas.util.DBUtil;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet(name = "EliminarTareaServlet", urlPatterns = {"/EliminarTareaServlet"})
public class EliminarTareaServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        if(id == null){ response.sendRedirect("lista.jsp"); return; }
        try(Connection conn = DBUtil.getConnection();
            PreparedStatement ps = conn.prepareStatement("SELECT descripcion, estatus FROM tareas WHERE id = ?")) {
            ps.setInt(1, Integer.parseInt(id));
            try(ResultSet rs = ps.executeQuery()){
                if(rs.next()){
                    String desc = rs.getString("descripcion");
                    String estatus = rs.getString("estatus");
                    if(!"realizada".equalsIgnoreCase(estatus)){
                        // no permitir eliminar si no está realizada
                        response.sendRedirect("lista.jsp");
                        return;
                    }
                    request.setAttribute("mensaje", "¿Desea eliminar la tarea: " + desc + " ?");
                    request.setAttribute("id", id);
                    request.setAttribute("accion", "EliminarTareaServlet?action=confirm");
                    request.getRequestDispatcher("confirmar.jsp").forward(request, response);
                    return;
                }
            }
        } catch(Exception e){ throw new ServletException(e); }
        response.sendRedirect("lista.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action"); // cuando confirmamos el POST
        if("confirm".equals(action)){
            String id = request.getParameter("id"); 
            try(Connection conn = DBUtil.getConnection();
                PreparedStatement ps = conn.prepareStatement("DELETE FROM tareas WHERE id = ?")) {
                ps.setInt(1, Integer.parseInt(id));
                ps.executeUpdate();
                response.sendRedirect("lista.jsp");
                return;
            } catch(Exception e){ throw new ServletException(e); }
        }
        response.sendRedirect("lista.jsp");
    }
}
