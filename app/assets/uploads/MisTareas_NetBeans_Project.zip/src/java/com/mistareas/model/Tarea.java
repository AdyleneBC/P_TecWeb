package com.mistareas.model;

import java.sql.Timestamp;

public class Tarea {
    private int id;
    private String descripcion;
    private Timestamp fechaCreacion;
    private String estatus;

    public Tarea(){}

    public Tarea(int id, String descripcion, Timestamp fechaCreacion, String estatus){
        this.id = id; this.descripcion = descripcion; this.fechaCreacion = fechaCreacion; this.estatus = estatus;
    }

    public int getId(){ return id; }
    public void setId(int id){ this.id = id; }

    public String getDescripcion(){ return descripcion; }
    public void setDescripcion(String descripcion){ this.descripcion = descripcion; }

    public Timestamp getFechaCreacion(){ return fechaCreacion; }
    public void setFechaCreacion(Timestamp fechaCreacion){ this.fechaCreacion = fechaCreacion; }

    public String getEstatus(){ return estatus; }
    public void setEstatus(String estatus){ this.estatus = estatus; }
}
