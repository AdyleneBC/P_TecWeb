package com.mistareas.servlets;

import com.mistareas.util.DBUtil;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet(name = "CambiarStatusServlet", urlPatterns = {"/CambiarStatusServlet"})
public class CambiarStatusServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        if(id == null){ response.sendRedirect("lista.jsp"); return; }
        // pedir confirmación antes de POST
        request.setAttribute("mensaje", "¿Desea marcar la tarea como realizada?"); 
        request.setAttribute("id", id);
        request.setAttribute("accion", "CambiarStatusServlet?action=confirm");
        request.getRequestDispatcher("confirmar.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action"); // confirm
        if("confirm".equals(action)){
            String id = request.getParameter("id");
            try(Connection conn = DBUtil.getConnection();
                PreparedStatement ps = conn.prepareStatement("UPDATE tareas SET estatus = 'realizada' WHERE id = ?")) {
                ps.setInt(1, Integer.parseInt(id));
                ps.executeUpdate();
                response.sendRedirect("lista.jsp");
                return;
            } catch(Exception e){ throw new ServletException(e); }
        }
        response.sendRedirect("lista.jsp");
    }
}
